setInterval(() => {
    let etoile = document.createElement("div");
    etoile.innerHTML = "✦";
    etoile.classList.add("etoile");

    etoile.style.left = Math.random() * window.innerWidth + "px";
    etoile.style.fontSize = Math.random() * 20 + 10 + "px";

    document.body.appendChild(etoile);

    setTimeout(() => {
        etoile.remove();
    }, 5000);
}, 200);